package com.example.ipadmod

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    companion object {
        const val TARGET_PACKAGE = "com.apple.android.music"
        // 768 = iPad 9,7" | 834 = iPad 11"
        const val TARGET_SW_DP = 768f
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != TARGET_PACKAGE) return

        XposedHelpers.findAndHookMethod(
            Activity::class.java,
            "attachBaseContext",
            Context::class.java,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val base = param.args[0] as? Context ?: return
                    try {
                        param.args[0] = scaled(base)
                    } catch (t: Throwable) {
                        XposedBridge.log("IpadMod: $t")
                    }
                }
            }
        )
    }

    private fun scaled(base: Context): Context {
        val dm = base.resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        val minPx = minOf(w, h)

        val dpi = (minPx * 160f / TARGET_SW_DP).toInt()
        val cfg = Configuration(base.resources.configuration)
        cfg.densityDpi = dpi
        cfg.screenWidthDp = (w * 160f / dpi).toInt()
        cfg.screenHeightDp = (h * 160f / dpi).toInt()
        cfg.smallestScreenWidthDp = (minPx * 160f / dpi).toInt()

        return base.createConfigurationContext(cfg)
    }
}
